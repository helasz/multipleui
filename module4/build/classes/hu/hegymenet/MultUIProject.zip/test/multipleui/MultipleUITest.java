package multipleui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javafx.stage.Stage;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Ignore;

/**
 * @author helasz (2017)
 */
public class MultipleUITest {
    
    public MultipleUITest() {
    }
    
    /**
     * Test of APrep (Arguments Preprocessor) method of class MultipleUI.
     * Take all the supported forms of arguments
     * and some of those not supported
     */
    @Test
    //@SuppressWarnings("empty-statement")
    public void testAPrep() {
        
        String cl;  // commandline, as passed to the main() class
        int cutHere;
        
        /* paired values:   expression, expected result */
        /**
         * handling space in a string is always painful
         * in java, on the commandline you clearly should
         * put these expression between quotation marks,
         * but here, in the test it will appear in the result,
         * so I just ommit them
         */
        final List<String> notSpaceSeparated = Arrays.asList( 
            /* single argument (optionKey only) options */
            "file"                  , "file=",
            "file extension"        , "file extension=",
            "f"                     , "f=",
            "/f"                    , "f=",
            "-f"                    , "f=",
            "--f"                   , "f=",
            "--flip"                , "flip=",
            "--flip-vertical"       , "flip-vertical=",
            
                 /* optionKey optionValue pairs */
         /* ========================================== */
            
                   /* optionKey starts with slash */
            "/f=-15"                , "f=-15",
            "/f=file.ext"           , "f=file.ext",
            "/f=/mnt/src.gzip"      , "f=/mnt/src.gzip",

                   /* optionKey starts with - */
            "-f=-15"                , "f=-15",
            "-f=file.ext"           , "f=file.ext",
            "-f=/mnt/src.gzip"      , "f=/mnt/src.gzip",
            "-DjavaClass/multi"      , "D=javaClass/multi",

                   /* optionKey starts with -- */
            "--f=-15"               , "f=-15",
            "--f=file.ext"          , "f=file.ext",
            "--f=/mnt/src.gzip"     , "f=/mnt/src.gzip",

            "--file=-15"            , "file=-15",
            "--file=file.ext"       , "file=file.ext",
            "--file=/mnt/src.gzip"  , "file=/mnt/src.gzip",

            "--fi-re=-15"           , "fi-re=-15",
            "--fi-re=file.ext"      , "fi-re=file.ext",
            "--fi-re=/mnt/src.gzip" , "fi-re=/mnt/src.gzip"
                );
        
        final List<String> spaceSeparated = Arrays.asList( 
                 /* optionKey optionValue pairs */
         /* ========================================== */
            
                   /* optionKey starts with slash */
            "/f file.ext"           , "f=file.ext",
            "/f space in.fname"     , "f=space in.fname",

                   /* optionKey starts with - */
            "-f file.ext"           , "f=file.ext",
            "-f space in.fname" , "f=space in.fname",

                   /* optionKey starts with -- */
            "--f file.ext"          , "f=file.ext",
            "--f space in.fname", "f=space in.fname",

            "--file file.ext"       , "file=file.ext",
            "--file sp in.fname", "file=sp in.fname",

            "--fi-re file.ext"      , "fi-re=file.ext",
            "--fi-re sp in.name", "fi-re=sp in.name"
                );
        
        /**
         * Test each well formed  case one by one
         */
        List<String> testCL = new ArrayList();
        testCL.add("");
        List<String> expectedResult = new ArrayList();
        expectedResult.add("");

        for (int i=0; i < notSpaceSeparated.size(); i=i+2) {
            testCL.set(0,notSpaceSeparated.get(i));
            expectedResult.set(0, notSpaceSeparated.get(i+1));
            System.out.println("Commandline reads: " + testCL.get(0));
            assertEquals( expectedResult,
                    MultipleUI.APrep(testCL) );
        }
        
        /**
         * the main() receives the following arguments 
         * in two pieces, cut in two at the first 'Space' 
         * so we do the same here
         */
        testCL.add("");
        for (int i=0; i < spaceSeparated.size(); i=i+2) {
            cutHere = spaceSeparated.get(i).indexOf(" ");
            testCL.set(0,spaceSeparated.get(i).substring(0, cutHere));
            testCL.set(1,spaceSeparated.get(i).substring(cutHere+1));
            expectedResult.set(0, spaceSeparated.get(i+1));
            System.out.println("Commandline reads: " + testCL.get(0) + 
                    " " + testCL.get(1));
            assertEquals( expectedResult,
                    MultipleUI.APrep(testCL) );
        }
    }
        
    /**
     * Should some of the commandline examples
     * fail, you can give them a try just 
     * one by one here
     */
    @Ignore
    @Test
    public void SingleArgument() {
    
        List<String> testCL = new ArrayList();
        testCL.add("/f file.ext");
        List<String> expectedResult = new ArrayList();
        expectedResult.add("f=file.ext");
    
        System.out.println("Commandline reads: " + testCL.get(0));
        assertEquals( expectedResult,
                MultipleUI.APrep(testCL) );
    
    
    }
    
}
