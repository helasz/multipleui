package multipleui.terminal;

import static multipleui.MultipleUI.Text;
import static multipleui.MultipleUI.logger;

public class Terminal {

    public int execute() {
        
        int returnValue = 0;
        
        logger.info(Text("TERMINAL_STARTED"));
        // TODO: put your code here

        
        
        return returnValue;
    }
    
    
}
