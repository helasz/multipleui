/**
 * The aim of this opensource project is to help 
 * newbies to start to develop Java code focusing 
 * on their idea itself instead of (re)inventing 
 * the basic building blocks of an application. 
 * I hope that more advanced users will also enjoy 
 * using it. It is completely free and without 
 * guarantee of any kind. No licensing at all, this
 * is my tribute to the opensource community I am 
 * in debt with since ages. If you quote me, that 
 * is welcome, but not neccessary. If you took 
 * your time to find this project, 
 * it is all yours :)
 * 
 * @author helasz@hegymenet.hu (2017)
 */
package multipleui;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import multipleui.terminal.Terminal;
import multipleui.terminalui.TerminalUI;

/**
 * This is an extended Java FX Application skeleton
 * which has the option to show its interface either
 * on an X window system or in terminal, or just the
 * terminal command line if so required.
 * 
 * Additions to a general Java FX Application 
 * includes:
 * 
 *   - commandline parsing
 *   - multilanguage support
 *   - simple logging system
 *   - changelog file
 *   - variables in properties file
 *   - terminal UI (Lanterna project)
 *   - conditional compilation
 * 
 * Conditional compilation is not a very orthodox 
 * solution, but I find it useful and I like it.
 * Should you want ot eliminate that, all you have 
 * to do is search for conditionals 'if (IFDEF)'
 * and delete these conditionals entirely.
 * 
 * The only addition with external dependency is
 * the Terminal UI (Lanterna is a project of 
 * Martin Berglund). If you do not need it you may
 * simply comment out the 'case "terminal_ui":'
 * branch from the switch conditionals at the very 
 * end of 'main(String[] args)'. In this case the
 * whole Terminal UI part will be not referenced 
 * any more and hence it will not be compiled, nor
 * required the relative external class library
 * lanterna.
 * 
 * There is one feature which has nothing to do 
 * with the application code itself, it is more 
 * a NetBeans, more precisely an 'Ant' task,
 * namely the automatic increasing of the 'build
 * number'. The 'build number' itself resides in 
 * the 'project.properties' file.
 * 
 * If you turn this skeleton into a Java FX 
 * Application template in NetBeans (>v8.0), 
 * you will not have to bother anymore with
 * renaming a bunch of appearances of the 
 * project name 'multipleui'.
 * 
 * Possible customization and improvements:
 * 
 * - elaborate commandline parsing, this is only
 *   a skeleton with the basic argument 'figures'
 * - proper error handling, validation of properties,
 *   default values, commandline arguments, etc.
 * - customize logging system, either the standard
 *   one, or a 3rd party one
 * - turn your properties file into xml, eventually
 *   with encryption
 * - elaborate ending processes, which fire up on
 *   Platform.exit() of Java FX (see class 'stop()')
 * - add further parts which you usually rewrite
 *   in every new project (database handling, 
 *   internet connection, etc.)
 * - etc.
 * 
 * If you put your project under versioning control 
 * system (my favourite for Java applications is 
 * subversion), in order to write great Java 
 * Application the only thing you will need is
 * the idea and some programming skills in Java 
 * (besides time and coffee of course, eventually 
 * a lot of them).
 */
public class MultipleUI extends Application {
    
    /** 
     * Condition of 'ifdef'
     * This boolean determines whether the 
     * conditional (logging) codes get compiled 
     * at all. Java compiler does ignore source 
     * code which will never be used. If this 
     * boolean is false (IFDEF=false) the
     * testing code parts will not be compiled.
     */
    public static final boolean IFDEF = true;

    //<editor-fold defaultstate="collapsed" desc="Variables Defining Locale">
    
    public static  String defaultLanguage;
    public static  String defaultCountry;
    public static  Locale defaultLocale;
    public static  String chosenLanguage;
    public static  String chosenCountry;
    public static  Locale chosenLocale;
    public static  ResourceBundle msg;
    
//</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Logging Variables">
    
    /**
     * In order to keep this sample simple it
     * neither applies 3rd party logging class
     * (as log4j for instance), or manipulates
     * java default log settings programmatically.
     * It just shows some basic java logging.
     */
    public static final Logger logger
            = Logger.getLogger("multipleUI");
    public static FileHandler fileHandler;
    public static SimpleFormatter logFormatter;
    
    /**
     * Logfile properties stored
     * in project.properties
     *
     * logfileName: if empty no logging will occur
     * logfileSize: maximum size of logfile
     *    0 (no size limit) -> lofile gets overwritten
     *      at each start
     * logfileCount: number of already rotated logfiles
     *
     */
    private static String logfileName;
    private static int logfileSize;
    private static boolean logfileAppend=true;
    
    //</editor-fold>
      
    /**
     * Project Properties
     * The file /res/project.properties
     * contains basic configuration data, again
     * for simplicity it is a plain text property 
     * file, no 3rd party dependencies.
     * NOTE: this file contains also 
     * the integer property 'BUILD', which
     * is automatically incremented after 
     * every successful build by ant.
     * (See also ${src.dir}/build.xml)
     */
    private static ResourceBundle resVars;

    /**
     * Date & Time format for using 
     * in filenames
     */
    public static SimpleDateFormat DTIME =
            new SimpleDateFormat("yyyyMMdd_HHmss");
    
    //<editor-fold defaultstate="collapsed" desc="Project Variables">
    
    /**
     * Project variables reflecting the ones
     * stored in the property file. It is
     * convenient to store them in a variable
     * also in order to be able to defer from
     * the values in the config file.
     */
    
    /**
     * Chosen user interface (see project.properties file)
     * Valid options are:
     * TERMINAL
     * TERMINAL_UI
     * JAVA_FX 
     * [default is JAVA_FX being this project originally such]
     */
    private static String uiMode = "default";
    
    //</editor-fold>
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Clp(args);
        
        //<editor-fold defaultstate="collapsed" desc="Load Variables From Config File">

        /**
         * Load the initial variable values from
         * config file ${src.dir}/multipleui/res/project.properties
         */
        resVars = ResourceBundle.getBundle("multipleui.res.project");

        //</editor-fold>

        //<editor-fold defaultstate="collapsed" desc="Setting up Locale">

        /**
         * Region/Language needs to be set before messaging
         * and logging features start
         */
        defaultLanguage = resVars.getString("DEFAULT_LANGUAGE");
        defaultCountry = resVars.getString("DEFAULT_COUNTRY");
        defaultLocale = new Locale(defaultLanguage, defaultCountry);
        if ( chosenLanguage != null && chosenCountry != null) {
            chosenLocale = new Locale(chosenLanguage, chosenCountry);
        } else {
            chosenLanguage = defaultLanguage;
            chosenCountry = defaultCountry;
            chosenLocale = defaultLocale;
        }
        
        msg = ResourceBundle.getBundle("multipleui.res.i18n.strings", chosenLocale);
        if (IFDEF) {
            logger.log(Level.INFO, "Default: {0}({1},{2})", 
                new Object[]{defaultLocale, defaultLanguage, defaultCountry});
            
            logger.log(Level.INFO, "Chosen: {0}({1},{2})", 
                new Object[]{chosenLocale, chosenLanguage, chosenCountry});
        }

        //</editor-fold>
        
        //<editor-fold defaultstate="collapsed" desc="Starting Message">

        /**
         * Printout Application name (from project.properties)
         * and version along with build number (as info log)
         */
        logger.log(Level.INFO, "Starting {0} v{1}.{2}.{3} build {4}",
            new Object[]{resVars.getString("APP_NAME"),
                resVars.getString("MAJOR"),
                    resVars.getString("MINOR"),
                        resVars.getString("PATCH"),
                            resVars.getString("BUILD")});
        //</editor-fold>

        //<editor-fold defaultstate="collapsed" desc="Initialize Logging">
        
        /**
         * Initialize logging
         */

        logfileName = resVars.getString("LOGFILE_NAME");
        // properties are all strings, but we need boolean here
        logfileAppend = "true".equals(
            resVars.getString("LOGFILE_APPEND").toLowerCase());
        
        // if logfilename is empty, no logging is required, otherwise:
        if ( !logfileName.isEmpty() ) {

            logfileSize = Integer.valueOf(resVars.getString("LOGFILE_SIZE"));
            
            if (IFDEF) {
                 /**
                  * this will not be present in logfile 
                  * which is not yet assigned
                  */
                logger.info(Text("LOGFILE") + ": " + logfileName + 
                        " (" + Text("MAX_SIZE") + ": " + logfileSize + "B)");
            }

            if ( logfileSize==0 ) {  
                /**
                 * no max. size -> overwrite last file
                 * to makr sure the log file will not 
                 * eat remarakble amount of precious 
                 * storage space
                 */
                logfileAppend = false;

            } else {  // check if maximum size was exceeded last time
                
                /**
                 * You can play with the location of the log file,
                 * in this sample project I have not.
                 */
                File logFile = new File(logfileName);
                if (!logFile.exists() || !logFile.isFile()) {
                    if (IFDEF) {
                        System.out.println(Text("LOGFILE_DOES_NOT_EXIST")
                                + logFile.getAbsolutePath());
                    }
                    
                } else {

                    if ( logFile.length() > logfileSize ) {
                        logger.log(Level.INFO, 
                            Text("LOGFILE_SIZE_LIMIT_EXCEEDED"), 
                            new Object[]{logfileName, logfileSize});

                        try {  
                            /**
                             * rename old file (logger will create a new one)
                             * (just append detailed date&time string) to the 
                             * filename /there are better, but remarkably 
                             * longer solutions for this filenaming/
                             */
                            String logfileEnding = "_" + DTIME.format(new Date());
                            Files.move(logFile.toPath(),
                                new File(logfileName  
                                    + logfileEnding).toPath());

                        } catch (IOException ex) {
                            Logger.getLogger(MultipleUI.class.getName()).
                                    log(Level.SEVERE, null, ex);
                        }
                    }
                }
                try {
                    fileHandler = new FileHandler(
                            logFile.toString(), logfileAppend);
                    logger.addHandler(fileHandler);
                    logFormatter = new SimpleFormatter();  
                    fileHandler.setFormatter(logFormatter);  
                
                } catch (IOException ex) {
                    Logger.getLogger(MultipleUI.class.getName()).log(Level.SEVERE, null, ex);
                
                } catch (SecurityException ex) {
                    Logger.getLogger(MultipleUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        //</editor-fold>

        //<editor-fold defaultstate="collapsed" desc="Initialize Variables">
        
        /**
         * Turn the rest of the loaded properties into variables.
         * Should you have default values in case the properties 
         * file does show empty value for the given key, this is
         * the place you can define your defaults (2nd parameter).
         * It is worth checking whether some of them were already 
         * set on commandline, in order not to override them.
         */
        if ( uiMode.equalsIgnoreCase("default") ) {
            /**
             * if uiMode is already set on commandline
             * we will not read the relative value from
             * the config file
             */
            uiMode = resVars.getString("UI_MODE");
        }
        
        
        /**
         * Although it is not recommended to hard code variables,
         * you are free to initialize them here in case you made
         * decision to have some of them anyway
         */
        String hardcodedVar = "HardToDeCode?";
        
        //</editor-fold>

        //<editor-fold defaultstate="collapsed" desc="Passing Control to the Chosen UI">

        switch (uiMode.toLowerCase()) {
            
            case "terminal_ui":
                TerminalUI terminalui = new TerminalUI();
                if ( terminalui.execute()==0 ){
                    logger.log(Level.INFO, 
                        Text("TERMINAL_UI_ENDED"));
                } else {
                    logger.log(Level.INFO, 
                        Text("TERMINAL_UI_ENDED_WITH_ERROR"));
                        /**
                        * this is where you can investigate 
                        * further the source of error
                        */                    
                }
                System.exit(0);
                
            case "terminal":
                Terminal terminal = new Terminal();
                if ( terminal.execute()==0 ){
                    logger.log(Level.INFO, 
                        Text("TERMINAL_ENDED"));
                } else {
                    logger.log(Level.INFO, 
                        Text("TERMINAL_ENDED_WITH_ERROR"));
                        /**
                        * this is where you can investigate 
                        * further the source of error
                        */                    
                }
                System.exit(0);

            default:

                /**
                 * if none of the above options is matched
                 * then fallback to Java FX, afterall this
                 * is a Java FX Application 
                 */
                launch(args);
                logger.log(Level.INFO, 
                    Text("JAVA_FX_ENDED"));
                System.exit(0);
        }
        
        //</editor-fold>
        
    }

    
    /**
     * Real starting of the Java FX 
     * Graphical User Interface
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("res/fxml/MainGUI.fxml"));
        Parent content = loader.load(); 
        Scene scene = new Scene(content);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * Stopping FXML application in case you 
     * jave chosen to run that UI
     * It is fired up on Platform.exit() or 
     * on closing the last scene
     * @throws Exception 
     */
    @Override
    public void stop() throws Exception {
        // this is just a temporary message, no translations
        System.out.println("Stopping Java FX Application");
        
    }

    
    /**
     * Returns the translated text of the parameter 
     * according to the chosen locale (if the given 
     * text is not yet translated, it falls back to
     * the default language). Messages considered as
     * part of the debugging (conditional compilation)
     * are only in English, there is no translation.
     * 
     * @param Message
     * @return 
     */
    public static String Text(String Message) {
        return msg.getString(Message);
    }

    /**
     * CommandLine Parsing
     * Recognized froms of arguments:
     * A) single argument:
     *    d
     *    directory
     *    "directory root"
     *    /d
     *    -d
     *    --d
     *    --directory-search
     * B) optionKey -  optionValue pair:
     *    /d C:\temp
     *    /d "C:\Program Files"
     *    /d=C:\temp
     *    /d="C:\Program Files"
     *    /d=-15
     *    /d=/usr/src  
     *    -d C:\temp
     *    -d "C:\Program Files"
     *    -d=-15
     *    -d=C:\temp
     *    -d="C:\Program Files"
     *    -d=/usr/src
     * 
     *  all the above mentioned examples do work substituting '-' with
     *  '--', plus in this case the optionKey (d) can be multiple-letter
     * expression (--directory, --dir-search), which is not working 
     * for single '-' option leading character because Java-like
     * argument should also work which takes the form:
     * 
     *    -Djavaclass/res   
     * 
     * @param args 
     */
    public static void Clp(String[] args) {

        //<editor-fold defaultstate="collapsed" desc="Variables">

        /**
         * optionKey   - name of the option to evaluate
         *               (it is not case-sensitive, but
         *                you can change that)
         * optionValue - the relative value, if any
         * 
         * optionKey may begin with either '-', or '--' 
         * or '/' or none (ie. just some text, between
         * quotation marks if it contains space). The mix
         * of leading characters '-' and '/' may be 
         * interpreted in some cases. 
         * Leading '--' and leading '-' can 
         * be used on the same line freely. 
         * After '-' only single-letter optionkey 
         * is supported, while after '--' both 
         * single-letter and multiple-letter 
         * are recognized.
         */
        List<String> argsList;
        ArrayList orderedArgs;
        String optionKey, optionValue;
        int cutHere;

        // convert the array of commandline arguments to a list
        argsList = new ArrayList<>(Arrays.asList(args));
        
        //</editor-fold>
        
        if (IFDEF) {
            String cmdLine = "";
            for (String arg : args) {
                cmdLine = cmdLine + " " + arg;
            }
            logger.log(Level.INFO, "Commandline reads: {0}", cmdLine);
        }

        /**
         * Reorganize the arguments in a fashioned way
         * (an array containing optionKey=optionValue pairs)
         */
        orderedArgs = APrep(argsList);

        /**
         * Evaluate the options
         * I put here three common examples, but you
         * are very likely to have more, or even 
         * different ones
         */
        String argPair = "";
        for (int i=0; i < orderedArgs.size(); i++) {
            argPair = (String) orderedArgs.get(i);
            // obviously optionKey is not supposed to contain '='
            cutHere = argPair.indexOf("=");
            optionKey = argPair.substring(0, cutHere);
            if (cutHere < orderedArgs.size()-1) {
                // not empty optionValue
                optionValue = argPair.substring(cutHere+1);
            } else {
                // empty optionValue
                optionValue = "";
            }
            switch (optionKey.toLowerCase()) {
                case "uimode":
                    // you should validate here 
                    
                    uiMode = optionValue;
                    break;
                    
                    
                case "language":
                    // you should validate here 
                    if (optionValue.length() > 0) {
                        chosenLanguage = optionValue;
                    }
                    
                    break;
                    
                case "country":
                    // you should validate here 
                    
                    chosenCountry = optionValue;
                    break;


                case "whatever":
                    /**
                     * you can evaluate here options with empty values also
                     */                    
                    break;

                default: System.out.println(
                        "Not handled argument: " + optionKey +
                                "(" + optionValue + ")");;
                                break;
            }       
        }
    }
    
    /**
     * Arguments Preprocess
     * This method does interpret the received String Array
     * as the one passed to the main(), and reformats it
     * into an ordered String Array, where each item appears
     * in 'optionKey=optionValue' (optionValue may be "") 
     * form which is pretty easy to parse. This method does 
     * the dirty part of recognizing (and dropping) the 
     * leading character(s) of the optionKey, and identifies
     * the respective optionValue if there is any.
     * @param opts
     * @return 
     */
    public static ArrayList APrep(List<String> opts) {
        
        String optionKey, optionValue;
        String[] optionPair;
        ArrayList resultArray = new ArrayList();
        
        for ( int i=0; i < opts.size(); i++) {
            optionValue = "";
            if ((opts.get(i)).startsWith("--")) { // Unix-like keyword? (--key)
                optionKey = opts.get(i).substring(2);  // drop leading --
            
                if ( i < opts.size()-1 ) { // end of commandline?
                    if (! (opts.get(i+1).startsWith("-") ||
                            opts.get(i+1).startsWith("/") ) ) { 
                        /**
                         * there is at least one more item in 
                         * commandline and it is not a new 
                         * optionKey, so it should be our optionValue
                         * Make sure the argument does not 
                         * get parsed again
                         */
                        i++;
                        optionValue = opts.get(i);
                    } else {
                        // check for inline optionValue (as: --dir=/usr/src)
                        optionPair = optionKey.split("=");
                        if ( optionPair.length > 1 ) {

                            /**
                             * You may use '=' for separating optionKey
                             * and optionValue only if optionValue does
                             * not contain further '=', otherwise parsing
                             * will fail.
                             *   --calc 21+12=12  (OK)
                             *
                             *   --calc=21+12=12  (WRONG!)
                             */
                            optionKey = optionPair[0];
                            optionValue = optionPair[1];
                        }
                    }

                } else {
                    // check for inline optionValue (as: --dir=/usr/src)
                    optionPair = optionKey.split("=");
                    if ( optionPair.length > 1 ) {

                        /**
                         * You may use '=' for separating optionKey
                         * and optionValue only if optionValue does
                         * not contain further '=', otherwise parsing
                         * will fail.
                         *   --calc 21+12=12  (OK)
                         *
                         *   --calc=21+12=12  (WRONG!)
                         */
                        optionKey = optionPair[0];
                        optionValue = optionPair[1];
                    }
                }
                resultArray.add(optionKey + "=" + optionValue);
                
            } else if (opts.get(i).startsWith("-") ||
                    opts.get(i).startsWith("/")  ) {  // DOS-like option

                // get the single-letter optionKey
                optionKey = opts.get(i).substring(1, 2);
                // extract the rest of the srting (the option value if any)
                optionValue = (opts.get(i) + "   ").substring(2).trim();

                if ( optionValue.length() > 0 ) { // optionValue is right here

                    if ( optionValue.substring(0,1).equals("=") ) { 
                        // DOS-like argument with "=" (drop the "=")
                        optionValue = optionValue.substring(1);
                    } // otherwise (Java-like argument) we are ready

                } else if ( i < opts.size()-1 ) { // further items in command line?
                    if (! (opts.get(i+1).startsWith("-")
                            || opts.get(i+1).startsWith("/") ) ) { // different option
                        // make sure the argument does not get parsed again
                        i++;
                        optionValue = opts.get(i);
                    }
                }
                resultArray.add(optionKey + "=" + optionValue);

                //</editor-fold>

            } else { // 'simple' text parameter, no leading -
                logger.log(Level.INFO,
                        "Text-only option: {0}", opts.get(i));
                optionKey = opts.get(i);
                resultArray.add(optionKey + "=");
            }
        }
        
        return resultArray;
    }
}
