/**
 * This class is built upon the Lanterna project
 * (thanks for Martin Berglund /and coworkers/).
 * You can download the most recent version here:
 * https://mvnrepository.com/artifact/com.googlecode.lanterna/lanterna
 * I am acutally using the last stable version
 * (v2.1.9), but I am planning to switch to 3.0
 * as soon as it will be released. I find lanterna
 * quite useful. 
 * 
 * (Lanterna has its advantages upon JCurses for 
 * instance: it is handling threads and has been
 * rewritten just now (February 2017) from scratch
 * implementing a decade or so of experience.)
 * 
 */
package multipleui.terminalui;

//import com.googlecode.lanterna.TerminalFacade;
//import com.googlecode.lanterna.input.Key;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.terminal.Terminal;

/**
 * @author helasz (2017)
 */
public class TerminalUI {
    
    public int execute() {
        
        int returnValue = 0;
        boolean keepRunning = true;
        Screen screen;
        int col, mincol, maxcol, row, minrow, maxrow;
  //      Key key;
        
/*
//        screen = TerminalFacade.createScreen();

        screen.startScreen();
        screen.putString(10, 4, "Press 'Escape' to exit!", 
                Terminal.Color.CYAN, Terminal.Color.YELLOW);
        screen.refresh();
        
        mincol = 20;
        minrow = 8;
        maxcol = screen.getTerminalSize().getColumns()-20;
        maxrow = screen.getTerminalSize().getRows()-15;
        col = mincol;
        row = minrow;
        
        while (keepRunning) {
            
            key = screen.readInput();
            while (key == null) {
                key = screen.readInput();
            }
            
            switch (key.getKind()) {
                case NormalKey:
                    screen.putString(col, row, key.toString().substring(11),
                        Terminal.Color.YELLOW, Terminal.Color.CYAN);
                    if ( col == maxcol ) {
                        col = mincol;
                        
                        if ( row == maxrow ) {
                            row = minrow;
                            screen.clear();

                        } else {
                            row = row + 1;
                        }
                    } else {
                        col = col + 1 ;
                    }
                    screen.refresh();
                    break;
                    
                case Escape:
                    keepRunning = false;
                    break;
                
                case Enter:
                    col = mincol;
                    if ( row == maxrow ) {
                        row = minrow;
                        screen.clear();

                    } else {
                        row = row + 1;
                    }
                    break;
            }
        }
        screen.stopScreen();
  */      
        return returnValue;
            }

}
